#!/bin/bash
set -e

echo "Starting setup for Perfect Numbers Network client..."

# 1. Check for Python
if command -v python3 &>/dev/null; then
    PYTHON=python3
elif command -v python &>/dev/null; then
    PYTHON=python
else
    echo "Python is not installed. Please install Python 3.7+ and rerun this script."
    exit 1
fi

echo "Using Python at: $(which $PYTHON)"

# 2. Check pip
if ! command -v pip &>/dev/null && ! command -v pip3 &>/dev/null; then
    echo "pip is not installed. Attempting to install pip..."
    curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
    $PYTHON get-pip.py
    rm get-pip.py
fi

# Use pip corresponding to Python
if command -v pip3 &>/dev/null; then
    PIP=pip3
else
    PIP=pip
fi

echo "Using pip at: $(which $PIP)"

# 3. Create virtual environment (optional but recommended)
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    $PYTHON -m venv venv
fi

# 4. Activate virtual environment
# Cross-platform activation
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    # Windows (Git Bash / WSL might also use bash)
    source venv/Scripts/activate
else
    # Linux / macOS
    source venv/bin/activate
fi

echo "Virtual environment activated."

# 5. Install requirements
if [ -f "requirements.txt" ]; then
    echo "Installing dependencies from requirements.txt..."
    $PIP install --upgrade pip
    $PIP install -r requirements.txt
else
    echo "requirements.txt not found. Skipping dependencies installation."
fi

echo "Setup complete!"
echo "To activate the virtual environment in the future, run:"
echo "source venv/bin/activate  # Linux/macOS"
echo "venv\\Scripts\\activate    # Windows"